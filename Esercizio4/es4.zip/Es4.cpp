//c++ -o Es4 Es4.cpp `root-config --cflags --glibs`
//Da termianle bisgna passare come primo argomento il numero di eventi che si vogliono generare, invece come secondo il numero di bin

#include <iostream>
#include <sstream>
#include <cstdlib>
#include <ctime>
#include <cmath>
#include <string>
#include <fstream>
#include <algorithm>
#include <vector>

#include <TStyle.h>
#include "TLorentzVector.h"
#include "TH1F.h"
#include "TH2F.h"
#include "TMinuit.h"
#include "TLegend.h"
#include "TApplication.h"
#include "TF1.h"
#include "TFile.h"
#include "TLatex.h"
#include "TGraphErrors.h"
#include "TMultiGraph.h"
#include "TCanvas.h"
#include "TRandom3.h"
#include "TMath.h"
#include "TROOT.h"
#include "TNtuple.h"

using namespace std;

int main(int argc, char** argv) {

	gStyle->SetOptStat(0000); 

	int nBin = atoi(argv[2]); // Numero di bin (passati da terminale)

	TApplication * grafica = new TApplication("grafica", 0, NULL);
	TCanvas * c = new TCanvas("histo", "histo");
	TH1F * histo = new TH1F("histo", "", nBin, 0, 10);

	double min_p = 0.; //Valore minimo del momento 
	double max_p = 10.; //Valore massimo del momento
	double min_teta = 0; //Valore minimo dell'angolo
	double max_teta = 6.28; //Valore massimo dell'angolo

	double pt[atoi(argv[1])]; //Vettore per la raccolta dei momenti trasversi 
	double pl[atoi(argv[1])]; //Vettore per la raccolta dei momenti longitudinali
	double pt_somma[nBin]; //Vettore per il calcolo della somma che verrà poi usata per calcolare il valor medio
	int w[nBin] = {0}; //Vettore per il conteggio degli eventi che verrà poi usato per calcolare il valor medio

	srand(time(NULL)); //Inizializzazione del seed per la generazione dei numeri pseudocasuali. 

	for(int i = 0; i < atoi(argv[1]); i++){
		double p = min_p + (max_p - min_p) * (double)rand() /(double) RAND_MAX; //Generazione del momento
		double teta = min_teta + (max_teta - min_teta) * (double)rand() /(double) RAND_MAX; //Generazione dell'angolo
		pt[i] = abs(p * sin(teta)); //Momento trasverso
		pl[i] = abs(p * cos(teta)); //Momento longitudinale

		//Calcolo del momento trasverso medio
		for(int k = 0; k < nBin; k++){
			if(pl[i] > 10/(double)nBin * k && pl[i] <= 10/(double)nBin * (k+1)){
				pt_somma[k] += pt[i];
				w[k]++;
				k == nBin; //Blocco il ciclo
			}
		}
	}

	//Riempimento dell'istogramma
	for (int j = 0; j < nBin; j++){
		histo -> Fill(10/(double)nBin * j, pt_somma[j] / w[j]); //Metodo Fill() con peso
	}

	histo -> GetXaxis() -> SetTitle("p_{L}");
	histo -> GetYaxis() -> SetTitle("<p_{T}>");
	histo -> Draw();
	grafica -> Run();
	return 0;
}
